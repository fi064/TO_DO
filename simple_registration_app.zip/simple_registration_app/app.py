from flask import Flask, render_template, redirect, url_for, session, flash
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, Length, EqualTo
from werkzeug.security import generate_password_hash, check_password_hash
import psycopg2
import os
from dotenv import load_dotenv
import traceback

# ----------------------------------------
# Load environment variables
# ----------------------------------------
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "dev-secret-key")

# ----------------------------------------
# Database configuration
# ----------------------------------------
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_NAME = os.getenv("DB_NAME", "simple_registration_app")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASS = os.getenv("DB_PASS", "postgres")
DB_PORT = os.getenv("DB_PORT", "5432")


def get_conn():
    """Create and return a PostgreSQL database connection."""
    return psycopg2.connect(
        host=DB_HOST,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASS,
        port=DB_PORT
    )


# ----------------------------------------
# Initialize database (auto-create users table)
# ----------------------------------------
def init_db():
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS users (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(100) NOT NULL,
                        email VARCHAR(100) UNIQUE NOT NULL,
                        password TEXT NOT NULL
                    );
                """)
                conn.commit()
        print("✅ Database initialized successfully.")
    except Exception as e:
        print("❌ Database initialization error:")
        traceback.print_exc()


# ----------------------------------------
# Flask-WTF Forms
# ----------------------------------------
class RegisterForm(FlaskForm):
    name = StringField("名前(なまえ)", validators=[DataRequired(), Length(min=2, max=50)])
    email = StringField("Email(メール)", validators=[DataRequired(), Email()])
    password = PasswordField("Password(パスワード)", validators=[DataRequired(), Length(min=6)])
    confirm = PasswordField(
        "Confirm Password(確認)",
        validators=[DataRequired(), EqualTo("password", message="Passwords must match.")]
    )
    submit = SubmitField("Register(登録)")


class LoginForm(FlaskForm):
    email = StringField("Email(メール)", validators=[DataRequired(), Email()])
    password = PasswordField("Password(パスワード)", validators=[DataRequired()])
    submit = SubmitField("Login(ログイン)")


# ----------------------------------------
# Routes
# ----------------------------------------

@app.route("/")
def index():
    """Homepage"""
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """User registration"""
    form = RegisterForm()

    if form.validate_on_submit():
        name = form.name.data.strip()
        email = form.email.data.strip().lower()
        password_hash = generate_password_hash(form.password.data)

        try:
            with get_conn() as conn:
                with conn.cursor() as cur:
                    # Check if email already exists
                    cur.execute("SELECT 1 FROM users WHERE email = %s;", (email,))
                    if cur.fetchone():
                        flash("This email is already registered. / このメールは登録されています。")
                        return redirect(url_for("login"))

                    # Insert new user
                    cur.execute(
                        "INSERT INTO users (name, email, password) VALUES (%s, %s, %s);",
                        (name, email, password_hash),
                    )
                    conn.commit()

            session["user_name"] = name
            flash("Registration successful! Welcome! / 登録成功! ようこそ。")
            return redirect(url_for("dashboard"))

        except Exception as e:
            print("❌ Detailed Database Error:")
            traceback.print_exc()
            flash("A database error occurred. / データベースエラーが発生しました。")

    return render_template("register.html", form=form)


@app.route("/login", methods=["GET", "POST"])
def login():
    """User login"""
    form = LoginForm()

    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        password = form.password.data

        try:
            with get_conn() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT id, name, password FROM users WHERE email=%s;", (email,))
                    user = cur.fetchone()

                    if user and check_password_hash(user[2], password):
                        session["user_id"] = user[0]
                        session["user_name"] = user[1]
                        flash("Login successful! / ログイン成功!")
                        return redirect(url_for("dashboard"))
                    else:
                        flash("Invalid email or password. / メールまたはパスワードが間違っています。")

        except Exception as e:
            print("❌ Detailed Database Error:")
            traceback.print_exc()
            flash("Database error. / データベースエラー。")

    return render_template("login.html", form=form)


@app.route("/dashboard")
def dashboard():
    """Dashboard"""
    if "user_name" not in session:
        flash("Please log in first. / まずログインしてください。")
        return redirect(url_for("login"))
    return render_template("dashboard.html", name=session.get("user_name"))


@app.route("/logout")
def logout():
    """Logout"""
    session.clear()
    flash("You have logged out. / ログアウトしました。")
    return redirect(url_for("index"))


# ----------------------------------------
# Error Handlers
# ----------------------------------------
@app.errorhandler(404)
def not_found_error(error):
    return render_template("404.html"), 404


@app.errorhandler(500)
def internal_error(error):
    return render_template("500.html"), 500


# ----------------------------------------
# Run app
# ----------------------------------------
if __name__ == "__main__":
    init_db()  # ✅ Automatically create users table if missing
    app.run(debug=True)
